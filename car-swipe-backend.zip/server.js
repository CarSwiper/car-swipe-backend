const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const Database = require('better-sqlite3');
const { nanoid } = require('nanoid');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());

// Öffne / erstelle DB
const db = new Database('./db.sqlite');

// Tabellen anlegen (falls nicht existieren)
db.prepare(`
CREATE TABLE IF NOT EXISTS cars (
  id TEXT PRIMARY KEY,
  title TEXT,
  brand TEXT,
  model TEXT,
  year INTEGER,
  price INTEGER,
  mileage INTEGER,
  images TEXT, -- JSON array
  lat REAL,
  lon REAL,
  created_at TEXT
)`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS swipes (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  car_id TEXT,
  action TEXT,
  created_at TEXT
)`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS saved (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  car_id TEXT,
  saved_at TEXT
)`).run();

// Helper: parse images JSON
function parseImages(row) {
  if (!row) return null;
  try { row.images = JSON.parse(row.images); } catch(e){ row.images = []; }
  return row;
}

// Endpoint: Feed (paginiert, simple)
app.get('/feed', (req, res) => {
  // optional: radius, lat/lon, min_price etc. — hier einfach alle
  const rows = db.prepare('SELECT * FROM cars ORDER BY created_at DESC').all();
  const cars = rows.map(parseImages);
  res.json({ ok: true, data: cars });
});

// Endpoint: Einzelnes Auto
app.get('/cars/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM cars WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ ok: false, error: 'not found' });
  res.json({ ok: true, data: parseImages(row) });
});

// Endpoint: Swipe (like/skip)
app.post('/swipe', (req, res) => {
  const { user_id = 'demo-user', car_id, action } = req.body;
  if (!car_id || !action) return res.status(400).json({ ok: false, error: 'car_id & action required' });
  const id = nanoid();
  const created_at = new Date().toISOString();
  db.prepare('INSERT INTO swipes (id,user_id,car_id,action,created_at) VALUES (?,?,?,?,?)')
    .run(id, user_id, car_id, action, created_at);
  res.json({ ok: true, id });
});

// Endpoint: Save (Merken)
app.post('/saved', (req, res) => {
  const { user_id = 'demo-user', car_id } = req.body;
  if (!car_id) return res.status(400).json({ ok: false, error: 'car_id required' });
  const id = nanoid();
  const saved_at = new Date().toISOString();
  db.prepare('INSERT INTO saved (id,user_id,car_id,saved_at) VALUES (?,?,?,?)').run(id, user_id, car_id, saved_at);
  res.json({ ok: true, id });
});

app.listen(PORT, () => {
  console.log(`Backend läuft auf http://localhost:${PORT}`);
});
