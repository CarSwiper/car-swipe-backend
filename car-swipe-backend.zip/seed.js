const Database = require('better-sqlite3');
const db = new Database('./db.sqlite');
const { nanoid } = require('nanoid');

const cars = [
  {
    title: 'VW Golf 7 1.6 TDI',
    brand: 'VW',
    model: 'Golf',
    year: 2016,
    price: 11900,
    mileage: 98000,
    images: [
      'https://picsum.photos/800/500?random=1',
      'https://picsum.photos/800/500?random=2'
    ],
    lat: 52.52,
    lon: 13.405
  },
  {
    title: 'BMW 320i F30',
    brand: 'BMW',
    model: '320i',
    year: 2015,
    price: 13950,
    mileage: 110000,
    images: [
      'https://picsum.photos/800/500?random=3',
      'https://picsum.photos/800/500?random=4'
    ],
    lat: 52.51,
    lon: 13.40
  },
  {
    title: 'Ford Fiesta',
    brand: 'Ford',
    model: 'Fiesta',
    year: 2014,
    price: 5990,
    mileage: 120000,
    images: [
      'https://picsum.photos/800/500?random=5'
    ],
    lat: 52.50,
    lon: 13.39
  }
];

const insert = db.prepare(`INSERT OR REPLACE INTO cars
(id,title,brand,model,year,price,mileage,images,lat,lon,created_at)
VALUES (?,?,?,?,?,?,?,?,?,?,?)`);

for (const c of cars) {
  insert.run(
    nanoid(),
    c.title,
    c.brand,
    c.model,
    c.year,
    c.price,
    c.mileage,
    JSON.stringify(c.images),
    c.lat,
    c.lon,
    new Date().toISOString()
  );
}

console.log('Seed data inserted.');
